import React, { Component } from 'react'
import moment from 'moment/moment'

class App extends Component {

  state = {
    status: false,
    userEmail: "",
    inputValue: "",
    messageValue: "",
    arrInputs: [""],
    messageInputValue: [""]
  }

  changeStatus = () => {
    this.setState({ status: !this.state.status })
  }
  changeEmail = (e) => {
    e.preventDefault()
    this.setState({ userEmail: this.state.inputValue })

  }
  sendMessage = (e) => {
    e.preventDefault()
    this.setState({messageValue: e.target.value})
    this.setState({ messageInputValue: this.state.messageValue })

var arrInputs = this.state.arrInputs
console.log('arrInputs', arrInputs);
arrInputs.push(this.state.messageValue);
console.log('arrInputs', arrInputs);
// var arr = this.state.messageInputValue
// console.log('arr', arr);
// arr.push(this.state.arrInputs);
// console.log(arr);
  }
  renderMessageSec = () => {
    return (
      <div className='messageSec'>
        <div className='messageSecTop'>
          <img className='chatImgAvatar' src="https://www.incredo.co/hubfs/download-7.png" />
          <span className='chatName'>Lusine</span>
        </div>
        <div className='messageSecMiddle'>
          {!this.state.userEmail ? this.renderEmailSec(): this.renderMessageBox()}
          {this.state.arrInputs ? this.renderMessageBoxUser(): this.renderMessageBoxUserNot()}
        </div>
        <div className='messageSecBottom'>
        <form className='messageSecBottomForm' onSubmit={this.sendMessage}>
          <input onChange={(e) => this.setState({messageValue: e.target.value})} className="messageInput" placeholder="Type your text here ...." type="text"/>
          <input className="messageSend" value="." type="submit"/>
          <span className='backtocartString'>Not using <a className='backtocartUrl' href="https://backtocart.co/">Backtocart</a> yet?</span>
        </form>
        </div>
      </div>
    )
  }
  renderMessageBox = () => {
    return (
      <div className='messageSecMiddleChild'>
      <p className="helloMessage">barev dzez {this.state.userEmail}, inchov karox em ognel dzez?</p>
      </div>
    )
  }
  renderMessageBoxUser = () => {
    if(this.state.userEmail.length > 0){
      return (
        <div className="userMessageBox"><span className="userEmail">{moment().format('LT')} {this.state.userEmail}</span><img className='userImgAvatar' src="https://www.incredo.co/hubfs/download-7.png" />
          <div className='messageSecMiddleChildUser'>
            <p className="helloMessageUser">{this.state.arrInputs}</p>
          </div>
        </div>
      )
    } else if(this.state.userEmail.length<1){
      return (
        <div className="errorMessageSendSec">
            <p className="errorMessageSend">please change E-mail</p>
        </div>
      )
    } if(this.state.messageValue === undefined){
      return (
        <div className='messageSecMiddleChildUser'>
        </div>
      )
    } else if(this.state.messageValue < 1){
      return (
        <div className='messageSecMiddleChildUser'>
        </div>
      )
    } else if(this.state.messageValue === ""){
      return (
        <div className='messageSecMiddleChildUser'>
        </div>
      )
    }
}
renderMessageBoxUserNot = () => {
  if(this.state.messageInputValue === undefined){
    return (
      <div className='messageSecMiddleChildUser'>
      </div>
    )
  } else if(this.state.messageInputValue < 1){
    return (
      <div className='messageSecMiddleChildUser'>
      </div>
    )
  }
}
  renderEmailSec = () => {
    return (
      <div className='messageSecMiddleChild'>
          <p className='emailText'>Lorem Ipsum is placeholder text commnly used in the graphic, print, and publis </p>
          <form className="formEmail" onSubmit={this.changeEmail}>
          <input onChange={(e) => this.setState({inputValue: e.target.value})} placeholder="E-mail"  className='emailInput' type="email"/>
          <input type="submit" className='emailSubmit'/>
          </form>
      </div>
    )
  }

  render () {
    return (
      <div className='container'>
        {this.state.status && this.renderMessageSec()}
        <img onClick={this.changeStatus} className='chatImg' src="https://www.incredo.co/hubfs/Layer-46.png" />
      </div>
    )
  }
}

export default App
